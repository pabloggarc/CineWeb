<nav>
    <div class="opciones">
        <a href="../controlador/controlador_mostrar_cartelera.php"> <img src="../imagenes/CineLogo.PNG" class="logo"
                alt="Logo de la página">
        </a>
        <a href="../controlador/controlador_mostrar_cartelera.php">CARTELERA</a>
        <a href="../controlador/controlador_perfil.php">PERFIL</a>
        <a href="../controlador/controlador_ver_reservas.php">ENTRADAS</a>
        <a href="../controlador/controlador_peliculas_vistas.php">COMENTAR</a>
    </div> 
</nav>