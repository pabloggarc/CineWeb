<nav>
    <div class="opciones">
        <a href="../controlador/controlador_admin_inicio.php"> <img src="../imagenes/CineLogo.PNG" class="logo"
                alt="Logo de la página">
        </a>
        <a href="../controlador/controlador_admin_inicio.php">PANEL DE GESTIÓN</a>
        <a href="../controlador/controlador_perfil.php">PERFIL</a>
        <a href="../controlador/controlador_estadisticas.php">ESTADISTICAS</a>
    </div> 
</nav>