<?php
    // Base de datos
    define('DB_HOST', 'mel.db.elephantsql.com');
    define('DB_NAME', 'gczgoasf');
    define('DB_USER', 'gczgoasf');
    define('DB_PASSWORD', '6ZkW17OxNVN65zkyhu5q-N39EnqCKL80');

    // Salas de cine
    define('PASILLO_SIZE', 5);
    define('PELICULAS_FILA','5');
?>